// Copyright (c) AlphaSierraPapa for the SharpDevelop Team
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of this
// software and associated documentation files (the "Software"), to deal in the Software
// without restriction, including without limitation the rights to use, copy, modify, merge,
// publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons
// to whom the Software is furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all copies or
// substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
// INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
// FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
// DEALINGS IN THE SOFTWARE.

using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace ICSharpCode.Decompiler.Tests.TestCases.Pretty
{
	internal class AsyncForeach
	{
		public async Task<int> SumIntegers(IAsyncEnumerable<int> items, CancellationToken token)
		{
			int sum = 0;
			await foreach (int item in items.WithCancellation(token))
			{
				if (!token.IsCancellationRequested)
				{
					sum += item;
					continue;
				}
				break;
			}
			return sum;
		}

		public async Task<int> MaxInteger(IAsyncEnumerable<int> items)
		{
			int max = int.MinValue;
			await foreach (int item in items)
			{
				if (item > max)
				{
					max = item;
				}
			}
			return max;
		}

		public async Task<int> SumWithConfigureAwait(IAsyncEnumerable<int> items)
		{
			int sum = 0;
			await foreach (int item in items.ConfigureAwait(continueOnCapturedContext: false))
			{
				sum += item;
			}
			return sum;
		}
	}
}
