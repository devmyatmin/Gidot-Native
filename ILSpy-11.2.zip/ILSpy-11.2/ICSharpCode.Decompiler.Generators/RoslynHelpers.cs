// Copyright (c) 2026 Siegfried Pammer
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this
// software and associated documentation files (the "Software"), to deal in the Software
// without restriction, including without limitation the rights to use, copy, modify, merge,
// publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons
// to whom the Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or
// substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
// INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
// FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
// DEALINGS IN THE SOFTWARE.

using Microsoft.CodeAnalysis;

namespace ICSharpCode.Decompiler.Generators;

public static class RoslynHelpers
{
	/// <summary>
	/// Post-init source declaring Microsoft.CodeAnalysis.EmbeddedAttribute. Every generator that
	/// emits embedded attribute types has to ship its own copy in its own post-init output; the
	/// declarations merge only while they stay partial and textually compatible, so all generators
	/// must build their copy from this single constant.
	/// </summary>
	public const string EmbeddedAttributeSource = @"
namespace Microsoft.CodeAnalysis
{
    internal sealed partial class EmbeddedAttribute : global::System.Attribute
    {
    }
}
";

	public static bool IsDerivedFrom(this INamedTypeSymbol type, INamedTypeSymbol baseType)
	{
		INamedTypeSymbol? t = type;

		while (t != null)
		{
			if (SymbolEqualityComparer.Default.Equals(t, baseType))
				return true;

			t = t.BaseType;
		}

		return false;
	}
}
